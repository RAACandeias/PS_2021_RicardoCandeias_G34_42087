
program :- 
	write('\33\[2J'),
    nl,write(' 1.Load Map '),nl,
    write(' 2.Load A*  '),nl,
    write(' 3.Load Goal: u '),nl,
	write(' 4.Load Goal: b '),nl,
	nl,	
	write(' 7.Find Path '),nl,
	write(' 8.Clear window '),nl,
	write(' 9.End Program '),nl,nl,
    write('enter your choice:'),nl,
    read(Option), Option > 0, Option =< 9,
    exe(Option).
	
program_next :- 
	write('enter your choice:'),nl,
    read(Option), Option > 0, Option =< 9,
    exe(Option).
	


exe(1) :- 
	ensure_loaded(['Map.pl']),write('Map loaded!'),nl,nl, 
	program_next.
exe(2) :- 
	ensure_loaded(['A(asterisk).pl']),write('A* loaded!'),nl,nl,    
	program_next.
exe(3) :- 
	consult(['Goal_u.pl']),write('Goal u set!'),nl,nl,    
	program_next.
exe(4) :- 
	consult(['Goal_b.pl']),write('Goal b set!'),nl,nl,    
	program_next.
	

exe(7) :- 
	write('Type start node: '),nl,read(Start),char_type(Start,lower),
	bestfirst(Start, Path),
	write('Calculated best Path: '),nl,
	write(Path),nl,nl,
	program_next.	
exe(8) :- program.	
exe(9) :- abort.
